import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useParams } from 'react-router-dom';
import InfiniteScroll from "react-infinite-scroll-component";
import { getData, getComments } from './Store/blogSlice';

const BolgDetails = () => {

    const { id } = useParams();
    const dispatch = useDispatch();

    const { userData, commentData } = useSelector(state => state.blog)

    const [data, setData] = useState([]);
    const [fetchLength, setFetchLength] = useState(0);
    const [hasMoreData, setHasMoreData] = useState(true);
    const [details, setDetails] = useState([]);


    useEffect(() => {
        dispatch(getData({ id: id }))
    }, [id])

    useEffect(() => {
        if (userData && userData.length > 0) {
            setDetails(userData[0]);
            console.log("userData", userData)
            document.title = userData[0].title;
        }
    }, [userData])

    useEffect(() => {
        // setData(commentData)
        fetchMore()
    }, [commentData])

    const viewComments = () => {
        dispatch(getComments());
        setHasMoreData(true);
    }

    const closeComments = () => {
        setData([]);
        setFetchLength(0);
    }

    const fetchMore = () => {
        let old_data = data;
        const comment_data = [];
        if (commentData && commentData.length > 0 && commentData.length >= fetchLength) {
            for (let i = 0; i < fetchLength + 10; i++) {
                comment_data.push(commentData[i])
            }
            setFetchLength(fetchLength + 10);
            old_data = old_data.concat(comment_data);
            setData(old_data);
        }
    }

    const fetchData = () => {
        if (data?.length >= commentData.length) {
            setHasMoreData(false);
            return;
        }
        setTimeout(() => {
            fetchMore(commentData)
            setHasMoreData(true);
        }, 500);
    }

    return (
        <>
            <div>
                <div>
                    {
                        details ?
                            <>
                                <div className="text-center m-10 text-2xl font-bold">
                                    {details.title}
                                </div>
                                <div className="border-4 mx-24 p-4 rounded mt-4">
                                    {details.body}
                                </div>
                                <div>
                                    <center>
                                        {
                                            data && data.length > 0 ?
                                                <button className="m-10 text-center border-4 w-40 border-indigo-300 rounded bg-indigo-200" onClick={closeComments}> <i class="fa fa-arrow-up" aria-hidden="true"></i> Close Comments </button>
                                                :
                                                <button className="m-10 text-center border-4 w-40 border-indigo-300 rounded bg-indigo-200" onClick={viewComments}> <i class="fa fa-arrow-down" aria-hidden="true"></i> View Comments </button>
                                        }
                                    </center>
                                </div>
                                {
                                    data && data.length > 0 ?
                                        <div id="comments" className="commentView">
                                            <InfiniteScroll
                                                dataLength={data.length}
                                                next={fetchData}
                                                hasMore={hasMoreData}
                                                loader={<h4 className="text-center mt-10">Loading...</h4>}
                                                endMessage={
                                                    <p className="text-center mt-10">
                                                        No More Comments !!
                                            </p>
                                                }
                                                scrollableTarget="comments"
                                            >
                                                {
                                                    data.map((item, index) => (
                                                        <div className="border-4 mx-24 p-4 rounded mt-4">
                                                            <div className="mx-5">
                                                                {item.title}
                                                            </div>
                                                        </div>
                                                    ))
                                                }
                                            </InfiniteScroll>
                                        </div>
                                        : ''
                                }
                            </>
                            : ''
                    }
                </div>
                <div>
                </div>
            </div>
        </>
    )
}

export default BolgDetails;