import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { trackPromise } from 'react-promise-tracker';
import blogService from './blogService'

export function getData({ id }) {
    return (dispatch) =>
        trackPromise(
            blogService.getData({ id })
                .then((response) => {
                    const { data } = response;
                    dispatch(setUserData(data))
                    return data
                }).catch(error => {
                    dispatch(setUserData([]))
                })
        )
}

export function getComments() {
    return (dispatch) =>
        trackPromise(
            blogService.getComments()
                .then((response) => {
                    const { data } = response;
                    dispatch(setCommentsData(data))
                    return data
                }).catch(error => {
                    dispatch(setCommentsData([]))
                })
        )
}


export const slice = createSlice({
    name: 'blogPost',
    initialState: {
        userData: [],
        commentData : []

    },
    reducers: {
        setUserData: (state, action) => {
            state.userData = action.payload;
        },
        setCommentsData: (state, action) => {
            state.commentData = action.payload;
        }
    },
    extraReducers: {}
});

export const { setUserData, setCommentsData } = slice.actions;

export default slice.reducer;
