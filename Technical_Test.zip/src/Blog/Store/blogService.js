import axios from 'axios';

class blogService {

    getData = ({ id }) => {
        return new Promise((resolve, reject) => {
            const request = axios.get('http://jsonplaceholder.typicode.com/posts'
            ,{
                params: {
                    id: id,
                }
            }
            )
            request.then((response) => {
                const { data,status } = response;
                if(status == 200){
                    resolve({ data });
                }else{
                    reject({ message : 'Error in retrive Data' });
                }
                
            }).catch((error) => {
                reject({ message: 'Something went wrong!!' });
            })
        });
    };


    getComments = () => {
        return new Promise((resolve, reject) => {
            const request = axios.get('http://jsonplaceholder.typicode.com/todos')
            request.then((response) => {
                const { data,status } = response;
                if(status == 200){
                    resolve({ data });
                }else{
                    reject({ message : 'Error in retrive Data' });
                }
                
            }).catch((error) => {
                reject({ message: 'Something went wrong!!' });
            })
        });
    };
}

const instance = new blogService();

export default instance;
