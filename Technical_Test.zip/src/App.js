import React from 'react'
import Blog from './Blog/blog'
import BolgDetails from './Blog/blogDetails'
import {Switch, Route, Redirect} from 'react-router-dom';

function App() {
  
  return (
    <>
      <Switch>
        <Route exact path="/" component={Blog} />
        <Route exact path="/details/:id" component={BolgDetails} />
        <Redirect to="/" />
      </Switch>
    </>
  );
}

export default App;
